# Copyright (c) OpenMMLab. All rights reserved.
from mmcv.utils import Registry

DATASETS = Registry('dataset')
PIPELINES = Registry('pipeline')
