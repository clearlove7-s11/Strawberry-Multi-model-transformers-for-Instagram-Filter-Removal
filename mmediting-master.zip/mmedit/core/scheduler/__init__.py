# Copyright (c) OpenMMLab. All rights reserved.
from .lr_updater import LinearLrUpdaterHook, ReduceLrUpdaterHook

__all__ = ['LinearLrUpdaterHook', 'ReduceLrUpdaterHook']
