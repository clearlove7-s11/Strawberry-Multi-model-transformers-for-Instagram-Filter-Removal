# Copyright (c) OpenMMLab. All rights reserved.
from .dist_utils import sync_random_seed

__all__ = ['sync_random_seed']
