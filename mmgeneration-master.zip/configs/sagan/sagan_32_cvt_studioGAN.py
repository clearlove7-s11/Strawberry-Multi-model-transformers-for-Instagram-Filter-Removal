_base_ = ['../_base_/models/sagan/sagan_32x32.py']
