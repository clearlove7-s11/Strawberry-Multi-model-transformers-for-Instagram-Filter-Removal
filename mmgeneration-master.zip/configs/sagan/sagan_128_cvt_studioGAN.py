_base_ = ['../_base_/models/sagan/sagan_128x128.py']
