import os
import shutil
import cv2
import torch
import numpy as np

out_file = '/root/data/AIM_RESULT/D_OUT'
if not os.path.exists(out_file):
    os.makedirs(out_file)

file_D = '/root/data/AIM_RESULT/D'
file_D_1 = '/root/data/AIM_RESULT/D_1'
file_D_2 = '/root/data/AIM_RESULT/D_2'
file_D_3 = '/root/data/AIM_RESULT/D_3'
file_D_4 = '/root/data/AIM_RESULT/D_4'
file_D_5 = '/root/data/AIM_RESULT/D_5'
file_D_6 = '/root/data/AIM_RESULT/D_6'
file_D_7 = '/root/data/AIM_RESULT/D_7'

file_lists = os.listdir(file_D)
for file_list in file_lists:
    print("handle:{}".format(file_list))
    file_path_out = os.path.join(out_file, file_list)
    if not os.path.exists(file_path_out):
        os.makedirs(file_path_out)

    file_path_D = os.path.join(file_D, file_list)
    file_path_D1 = os.path.join(file_D_1, file_list)
    file_path_D2 = os.path.join(file_D_2, file_list)
    file_path_D3 = os.path.join(file_D_3, file_list)
    file_path_D4 = os.path.join(file_D_4, file_list)
    file_path_D5 = os.path.join(file_D_5, file_list)
    file_path_D6 = os.path.join(file_D_6, file_list)
    file_path_D7 = os.path.join(file_D_7, file_list)

    img_lists = os.listdir(file_path_D)
    for img_list in img_lists:
        src_img_out = os.path.join(file_path_out, img_list)
        src_img_D = os.path.join(file_path_D, img_list)
        src_img_D1 = os.path.join(file_path_D1, img_list)
        src_img_D2 = os.path.join(file_path_D2, img_list)
        src_img_D3 = os.path.join(file_path_D3, img_list)
        src_img_D4 = os.path.join(file_path_D4, img_list)
        src_img_D5 = os.path.join(file_path_D5, img_list)
        src_img_D6 = os.path.join(file_path_D6, img_list)
        src_img_D7 = os.path.join(file_path_D7, img_list)
        img_D = cv2.imread(src_img_D)
        img_D1 = cv2.imread(src_img_D1)
        img_D2 = cv2.imread(src_img_D2)
        img_D3 = cv2.imread(src_img_D3)
        img_D4 = cv2.imread(src_img_D4)
        img_D5 = cv2.imread(src_img_D5)
        img_D6 = cv2.imread(src_img_D6)
        img_D7 = cv2.imread(src_img_D7)

        img_D1 = cv2.rotate(img_D1, cv2.ROTATE_90_COUNTERCLOCKWISE)
        img_D2 = cv2.rotate(img_D2, cv2.ROTATE_180)
        img_D3 = cv2.rotate(img_D3, cv2.ROTATE_90_CLOCKWISE)
        img_D4 = cv2.flip(img_D4, 0)
        img_D5 = cv2.flip(img_D5, 0)
        img_D5 = cv2.rotate(img_D5, cv2.ROTATE_90_COUNTERCLOCKWISE)
        img_D6 = cv2.flip(img_D6, 1)
        img_D7 = cv2.flip(img_D7, 0)
        img_D7 = cv2.rotate(img_D7, cv2.ROTATE_90_CLOCKWISE)
        img_out = cv2.add(img_D/8, img_D1/8)
        img_out = cv2.add(img_out, img_D2/8)
        img_out = cv2.add(img_out, img_D3/8)
        img_out = cv2.add(img_out, img_D4/8)
        img_out = cv2.add(img_out, img_D5/8)
        img_out = cv2.add(img_out, img_D6/8)
        img_out = cv2.add(img_out, img_D7/8)
        # img_out = (img_D+ img_D1 +img_D2+img_D3+img_D4+img_D5+img_D6+img_D7)/8
        img_out = img_out.astype(np.uint8)

        cv2.imwrite(src_img_out, img_out)
        # print('123')





