import os
import shutil
import cv2
import torch
import numpy as np

out_file1 = '/root/data/AIM_RESULT/D_OUT3'
if not os.path.exists(out_file1):
    os.makedirs(out_file1)

in_file = '/root/data/AIM_RESULT/D_OUT'


file_lists = os.listdir(in_file)
for file_list in file_lists:
    file_path_in = os.path.join(in_file, file_list)
    file_path_out = os.path.join(out_file1, file_list)
    if not os.path.exists(file_path_out):
        os.makedirs(file_path_out)

    img_lists = os.listdir(file_path_in)
    img_lists = sorted(img_lists)
    list_num = [0, 4, 7, 10]
    # 0 4 7 10
    # 9 8
    # funsion_list = ['Amaro', 'Hudson', 'Nashville', 'X-ProII']
    for num in list_num:
        img1 = cv2.imread(os.path.join(file_path_in, img_lists[num]))
        img2 = cv2.imread(os.path.join(file_path_in, img_lists[9]))
        img_out = cv2.add(img1*0.4, img2*0.6)
        img_out = img_out.astype(np.uint8)
        cv2.imwrite(os.path.join(file_path_out, img_lists[num]), img_out)
        img_path_out = os.path.join(file_path_out, img_lists[num])

    img1 = cv2.imread(os.path.join(file_path_in, img_lists[8]))
    img2 = cv2.imread(os.path.join(file_path_in, img_lists[9]))
    img_out = cv2.add(img1 * 0.45, img2 * 0.55)
    img_out = img_out.astype(np.uint8)
    cv2.imwrite(os.path.join(file_path_out, img_lists[8]), img_out)
    img_out = cv2.add(img1 * 0.55, img2 * 0.45)
    img_out = img_out.astype(np.uint8)
    cv2.imwrite(os.path.join(file_path_out, img_lists[9]), img_out)

    list_num2 = [1, 2, 3, 5, 6]
    for num in list_num2:
        img1 = cv2.imread(os.path.join(file_path_in, img_lists[num]))
        img2 = cv2.imread(os.path.join(file_path_in, img_lists[9]))
        img_out = cv2.add(img1*0.8, img2*0.2)
        img_out = img_out.astype(np.uint8)
        cv2.imwrite(os.path.join(file_path_out, img_lists[num]), img_out)
        img_path_out = os.path.join(file_path_out, img_lists[num])









