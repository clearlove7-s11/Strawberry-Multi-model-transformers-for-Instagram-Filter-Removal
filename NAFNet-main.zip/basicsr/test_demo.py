# ------------------------------------------------------------------------
# Copyright (c) 2022 megvii-model. All Rights Reserved.
# ------------------------------------------------------------------------
# Modified from BasicSR (https://github.com/xinntao/BasicSR)
# Copyright 2018-2020 BasicSR Authors
# ------------------------------------------------------------------------
import torch
import os
# from basicsr.data import create_dataloader, create_dataset
from basicsr.models import create_model
from basicsr.train import parse_options
from basicsr.utils import FileClient, imfrombytes, img2tensor, padding, tensor2img, imwrite
from basicsr.data.dataset_AIM import DataLoaderTrain,DataLoaderTest,DataLoaderVal
# from basicsr.utils import (get_env_info, get_root_logger, get_time_str,
#                            make_exp_dirs)
# from basicsr.utils.options import dict2str
from tqdm import tqdm
import cv2

def save_img(filepath, img):
    # cv2.imwrite(filepath,cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
    cv2.imwrite(filepath,img)

def main():
    # parse options, set distributed setting, set ramdom seed
    opt = parse_options(is_train=False)
    opt['num_gpu'] = torch.cuda.device_count()
    result_dir = opt['result_dir']
    img_test_path = opt['TEST_DIR']
    test_set = DataLoaderTest(img_test_path, {'patch_size': 256})
    test_loader = torch.utils.data.DataLoader(dataset=test_set, batch_size=1,
                                               shuffle=False, num_workers=8, drop_last=False, pin_memory=True)
    ## 2. run inference
    opt['dist'] = False
    model = create_model(opt)
    print("result_dir:{}".format(result_dir))

    for idx, val_data in enumerate(tqdm(test_loader)):
        img = val_data[0]
        img_name = val_data[1]

        # img = img2tensor(img, bgr2rgb=True, float32=True)
        model.feed_data_test(data={'lq': img})
        if model.opt['val'].get('grids', False):
            model.grids()

        model.test()
        if model.opt['val'].get('grids', False):
            model.grids_inverse()

        visuals = model.get_current_visuals()

        sr_img = tensor2img([visuals['result']])
        # print(sr_img)
        keep_dir = os.path.join(result_dir, img_name[0].split('_')[0])
        # print('123')
        if not os.path.exists(keep_dir):
            os.makedirs(keep_dir)
        save_img((os.path.join(keep_dir, img_name[0]+'.png')), sr_img)



    # ## 1. read image
    # file_client = FileClient('disk')
    #
    # img_bytes = file_client.get(img_test_path, None)
    # try:
    #     img = imfrombytes(img_bytes, float32=True)
    # except:
    #     raise Exception("path {} not working".format(img_path))
    #
    # img = img2tensor(img, bgr2rgb=True, float32=True)
    #
    # model.feed_data(data={'lq': img.unsqueeze(dim=0)})
    #
    # if model.opt['val'].get('grids', False):
    #     model.grids()
    #
    # model.test()
    #
    # if model.opt['val'].get('grids', False):
    #     model.grids_inverse()
    #
    # visuals = model.get_current_visuals()
    # sr_img = tensor2img([visuals['result']])
    # imwrite(sr_img, output_path)
    #
    # print(f'inference {img_path} .. finished. saved to {output_path}')

if __name__ == '__main__':
    main()

