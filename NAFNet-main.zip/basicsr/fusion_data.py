import os
import shutil
import cv2
import numpy as np

flies_dir1 = '/root/data/AIM_RESULT/C'
flies_dir2 = '/root/data/AIM_RESULT/D'
out_dir = '/root/data/AIM_RESULT/CD'

if not os.path.exists(out_dir):
    os.makedirs(out_dir)

file_lists = os.listdir(flies_dir1)
for file_list in file_lists:
    flies_dir1_path = os.path.join(flies_dir1, file_list)
    flies_dir2_path = os.path.join(flies_dir2, file_list)
    flies_imgs = os.listdir(flies_dir1_path)
    print(file_list)
    keep_dir = os.path.join(out_dir, file_list)
    if not os.path.exists(keep_dir):
        os.makedirs(keep_dir)
    for flies_img in flies_imgs:
        flies_img1_path = os.path.join(flies_dir1_path, flies_img)
        flies_img2_path = os.path.join(flies_dir2_path, flies_img)
        img1 = cv2.imread(flies_img1_path)
        img2 = cv2.imread(flies_img2_path)

        img_out = (img2+img1)/2
        keep_path = os.path.join(out_dir, file_list, flies_img)

        img_out = img_out.astype(np.uint8)
        cv2.imwrite(keep_path, img_out)



