import os
import shutil
file_root ='/root/data/AIM_RESULT/K'
change_file_dirs =[90,91,92,93,94,95,96,97,98,99]

if os.path.exists(file_root):
    for change_file_dir in change_file_dirs:
        change_file_name =str(change_file_dir)+'_Hudson.png'
        if change_file_dir != 90:
            out_file_dir = change_file_dir-1
        else:
            out_file_dir = 99
        src_file_path = os.path.join(file_root, str(change_file_dir), change_file_name)
        out_file_path = os.path.join(file_root, str(out_file_dir), change_file_name)
        shutil.move(src_file_path, out_file_path)

    for change_file_dir in change_file_dirs:
        if change_file_dir != 99:
            out_file_name = change_file_dir+1
        else:
            out_file_name = 90
        src_file_name =str(out_file_name)+'_Hudson.png'
        out_file_name =str(change_file_dir)+'_Hudson.png'
        src_file_path = os.path.join(file_root, str(change_file_dir), src_file_name)
        out_file_path = os.path.join(file_root, str(change_file_dir), out_file_name)
        shutil.move(src_file_path, out_file_path)
else:
    print('no exists src')