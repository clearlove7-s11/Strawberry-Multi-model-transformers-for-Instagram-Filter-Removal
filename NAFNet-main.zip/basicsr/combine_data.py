import os
import shutil
file_root ='/root/data_end/AIM_Uformer_END/IFFI-dataset-lr-train-all/IFFI-dataset-lr-train'
out_root = '/root/data_end/AIM_Uformer_END/IFFI-dataset-lr-train-new'

# move_name = ['Amaro.png', 'Clarendon.png', 'Gingham.png', 'He-Fe.png',
#          'Hudson.png', 'Lo-Fi.png', 'Mayfair.png', 'Nashville.png', 'Perpetua.png',
#          'Valencia.png', 'X-ProII.png']
# move_name = ['Amaro.png', 'Clarendon.png', 'Gingham.png', 'Nashville.png']

move_name = ['Original.jpg']


if not os.path.exists(out_root):
    os.makedirs(out_root)

if os.path.exists(file_root):
    file_lists = os.listdir(file_root)
    for file_list in file_lists:
        print("handle:{}".format(file_list))
        file_path = os.path.join(file_root, file_list)
        out_file_path = os.path.join(out_root, file_list)
        if not os.path.exists(out_file_path):
            os.makedirs(out_file_path)

        img_lists = os.listdir(file_path)
        for img_list in img_lists:
            fname_ = img_list.split('_')[1]
            if fname_ in move_name:
                img_path = os.path.join(file_path, img_list)
                out_img_path = os.path.join(out_file_path, img_list)
                shutil.copy(img_path, out_img_path)
                # print('123')
else:
    print('no exists src')