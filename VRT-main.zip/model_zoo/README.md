model_zoo

The VRT pretrained models will be downloaded automatically from [here](https://github.com/JingyunLiang/VRT/releases).