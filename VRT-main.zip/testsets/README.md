testsets

The used testsets will be downloaded automatically from [here](https://github.com/JingyunLiang/VRT/releases). 