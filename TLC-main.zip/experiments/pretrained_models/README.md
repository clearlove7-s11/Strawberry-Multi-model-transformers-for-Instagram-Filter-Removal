### Pretrained Models
---
Our TLC can improve performance without re-training existing models. Here, we provide the links to the official checkpoints of HINet, MPRNet and Restormer.

* [HINet-GoPro](https://drive.google.com/file/d/1dw8PKVkLfISzNtUu3gqGh83NBO83ZQ5n/view?usp=sharing)
* [HINet-REDS](https://drive.google.com/file/d/1uYH8XvLgrn-Vg6L0NjUcO2Fblhqrc8TU/view?usp=sharing)
* [MPRNet-GoPro](https://drive.google.com/file/d/1QwQUVbk6YVOJViCsOKYNykCsdJSVGRtb/view)
* [Restormer-GoPro](https://drive.google.com/file/d/1pwcOhDS5Erzk8yfAbu7pXTud606SB4-L/view)