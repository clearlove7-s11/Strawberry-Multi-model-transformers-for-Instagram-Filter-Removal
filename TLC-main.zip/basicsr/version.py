# GENERATED VERSION FILE
# TIME: Tue May 24 15:28:43 2022
__version__ = '1.2.0+b6c7c92'
short_version = '1.2.0'
version_info = (1, 2, 0)
